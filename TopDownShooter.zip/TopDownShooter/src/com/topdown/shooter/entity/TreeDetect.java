package com.topdown.shooter.entity;

public class TreeDetect extends Detect {

	public TreeDetect(int x, int y, int range) {
		super(x, y, range);
		// TODO Auto-generated constructor stub
	}

}
